import java.io.*;
import java.net.*;
import java.awt.*;
import javax.swing.*;
 
class Command {
    public final static int FILE_NAME = 0x00;
    public final static int FILE_SIZE = 0x01;
    public final static int SEND_BEGIN = 0x02;
    public final static int SEND_END = 0x03;
}
 
public class Server extends JFrame{
    private JTextArea textArea = new JTextArea();
    private MyPanel panel = new MyPanel();
    private String receiveFileName;
    private ImageIcon icon = null;
    public Server(){
        super("���� �޴� ����");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 
        Container c = getContentPane();
 
        JPanel textPanel = new JPanel();
        JScrollPane scrollPane = new JScrollPane(textArea);
        textPanel.setLayout(new BorderLayout());
        textPanel.add(scrollPane, BorderLayout.CENTER);
        textPanel.setPreferredSize(new Dimension(this.getWidth(), 50));
        textArea.setEnabled(false);
 
        c.add(textPanel, BorderLayout.NORTH);
        c.add(panel, BorderLayout.CENTER);
 
        setSize(500, 300);
        setVisible(true);
        this.fileReceiver();
    }
    class MyPanel extends JPanel{
        private Image img;
        public void paintComponent(Graphics g){
            super.paintComponent(g);
            if(icon != null){
                img = icon.getImage();
                g.drawImage(img, 0, 0, this);
            }
        }
    }
 
    private static int receiveInt(BufferedInputStream fin) throws IOException {
        int value;
        value = fin.read();
        value |= fin.read() << 8;
        value |= fin.read() << 16;
        value |= fin.read() << 24;
        return value;
    }
    
    
    public void fileReceiver(){
        BufferedInputStream fin = null;
        BufferedOutputStream fout = null;
        ServerSocket listener = null;
        Socket socket = null;
        try {
            listener = new ServerSocket(9999);
            socket = listener.accept();
            textArea.append("�����\n");
 
            fin = new BufferedInputStream(socket.getInputStream());
            int cmd;
            String fileName = null;
            long length=0;
 
 
            cmd = fin.read();
            if (cmd == Command.FILE_NAME) {
                int nameSize = receiveInt(fin);
                textArea.append("���۹��� ���� �̸� ���� :" + nameSize + "\n");
                byte fname[] = new byte[nameSize];
                fin.read(fname);
                fileName = new String(fname);
                textArea.append("���۹��� ���� �̸�:" + fileName + "\n");
                receiveFileName = "copy_" + fileName;
                textArea.append("������ ���� �̸�:" + receiveFileName + "\n");
                fout = new BufferedOutputStream(new FileOutputStream(receiveFileName));
            } else {
                textArea.append("���� ���� ����" + cmd + "\n");
                socket.close();
                listener.close();
                return;
            }
 
            cmd = fin.read();
            if (cmd == Command.FILE_SIZE) {
                int lenghLow = receiveInt(fin);
                int lenghHigh = receiveInt(fin);
                length = lenghHigh;
                length <<= 32;
                length += lenghLow;
                textArea.append("���۹��� ���� ũ��:" + length + "\n");
            } else {
                textArea.append("���� ���� ����" + cmd + "\n");
                if (fout != null)
                    fout.close();
                socket.close();
                listener.close();
                return;
            }
 
            cmd = fin.read();
            if (cmd == Command.SEND_BEGIN) {
                int numberToRead;
                while (length >0) {
                    byte b[] = new byte[2048];
                    if (length < b.length)
                        numberToRead = (int)length;
                    else
                        numberToRead = b.length;
                    int numRead = fin.read(b, 0, numberToRead);
                    if (numRead <= 0) {
                        if (length > 0) {
                            textArea.append("���� ������ �߻��߽��ϴ�. ���� ����Ʈ: " + numRead + " ���� ����Ʈ:" + length + "\n");
                            break;
                        }
                    } else {
                        textArea.append(".");
                        fout.write(b, 0, numRead);
                        length -= numRead;
                    }
                }
 
                cmd = fin.read();
                if (cmd == Command.SEND_END) {
                    textArea.append("\n���� ���� ����. ���� �j���� ����Ǿ����ϴ�." + "\n");
                    icon = new ImageIcon(receiveFileName);
                    this.setSize(icon.getIconWidth(), icon.getIconHeight());
                    panel.repaint();
 
                } else {
                    textArea.append("\n���� ���� ����" + cmd + "\n");
                }
                if (fout != null)
                    fout.close();
                socket.close();
                listener.close();
            }
        } catch (IOException e) {
            textArea.append("���� ���� �� ������ �߻��߽��ϴ�.\n");
        }
    }
 
    public static void main(String[] args){
        new Server();
    }
}